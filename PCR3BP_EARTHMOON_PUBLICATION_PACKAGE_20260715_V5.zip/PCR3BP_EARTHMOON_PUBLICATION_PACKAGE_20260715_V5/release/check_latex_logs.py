#!/usr/bin/env python3
from pathlib import Path
import json,re,sys
root=Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve(); errors=[]
final_patterns=[r'undefined references',r'Citation .+ undefined',r'There were undefined references',r'Empty bibliography',r'Please \(re\)run Biber',r'Fatal error',r'Emergency stop',r'LaTeX Error:']
build_patterns=[r'Fatal error',r'Emergency stop',r'LaTeX Error:']
for lang,stem in [('en','earth_moon_pcr3bp_en'),('pt','earth_moon_pcr3bp_pt')]:
 d=root/'paper'/lang
 for name in [stem+'.pdf',stem+'.tex',stem+'.bbl',stem+'.log','latex_build.log']:
  if not (d/name).is_file(): errors.append('missing:'+str((d/name).relative_to(root)))
 p=d/(stem+'.log')
 if p.is_file():
  text=p.read_text(errors='replace')
  for pat in final_patterns:
   if re.search(pat,text,re.I): errors.append(f'{lang}:{p.name}:{pat}')
 p=d/'latex_build.log'
 if p.is_file():
  text=p.read_text(errors='replace')
  for pat in build_patterns:
   if re.search(pat,text,re.I): errors.append(f'{lang}:{p.name}:{pat}')
print(json.dumps({'root':str(root),'errors':errors,'status':'PASS' if not errors else 'FAIL'},indent=2)); sys.exit(0 if not errors else 1)
