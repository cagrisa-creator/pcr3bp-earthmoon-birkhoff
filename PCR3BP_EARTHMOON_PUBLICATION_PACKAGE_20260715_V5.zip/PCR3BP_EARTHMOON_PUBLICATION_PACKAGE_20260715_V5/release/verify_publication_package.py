#!/usr/bin/env python3
from pathlib import Path
import json,sys,zipfile
root=Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve(); errors=[]
required=['paper/en/earth_moon_pcr3bp_en.tex','paper/pt/earth_moon_pcr3bp_pt.tex','paper/en/earth_moon_pcr3bp_en.pdf','paper/pt/earth_moon_pcr3bp_pt.pdf','paper/en/earth_moon_pcr3bp_en.docx','paper/pt/earth_moon_pcr3bp_pt.docx','paper/shared/references.bib','data/artifact_registry.json','data/KEPLER_COUNT_RECONCILIATION.json','src/core/outer_dynamic.cpp','src/core/high_energy_cert.cpp','release/check_latex_logs.py','private_review/HUMAN_VERIFICATION_CHECKLIST_PRIVATE.md','CORRECTIONS_AUDIT.md']
for rel in required:
 if not (root/rel).is_file(): errors.append('missing:'+rel)
reg=json.loads((root/'data/artifact_registry.json').read_text())
if len(reg.get('parents',[]))!=10: errors.append('parent_count')
r=json.loads((root/'data/KEPLER_COUNT_RECONCILIATION.json').read_text())
if r.get('authoritative_accepted_interval_leaves')!=2968830 or r.get('difference')!=5449: errors.append('kepler_reconciliation')
for doc in [root/'paper/en/earth_moon_pcr3bp_en.docx',root/'paper/pt/earth_moon_pcr3bp_pt.docx']:
 if doc.is_file():
  try:
   with zipfile.ZipFile(doc) as z:
    if z.testzip() is not None: errors.append('docx_crc:'+doc.name)
  except Exception as e: errors.append('docx:'+repr(e))
for lang in ['en','pt']:
 text=(root/f'paper/{lang}/earth_moon_pcr3bp_{lang}.tex').read_text()
 for token in ['LS2025','doCarmoLima1969','GrisaCZ2026','KEPLER\\_COUNT\\_RECONCILIATION.json']:
  if token not in text: errors.append(f'manuscript:{lang}:{token}')
for rel in ['src/symbolic/symbolic_check.py','src/symbolic/symbolic_shear_hessian_check.py']:
 if 'src" / "core" / "outer_dynamic.cpp"' not in (root/rel).read_text(): errors.append('symbolic_path:'+rel)
print(json.dumps({'root':str(root),'errors':errors,'status':'PASS' if not errors else 'FAIL'},indent=2)); sys.exit(0 if not errors else 1)
