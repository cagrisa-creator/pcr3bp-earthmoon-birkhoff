# Reproducibility guide

## Clean local verification

```bash
make verify
```

This checks package structure, both symbolic derivations, the exact C++ source path, and final LaTeX logs.

## External parents

Run `make verify-parents PARENTS=/path/to/parents`, then the parent-specific verifiers and GCC/Clang replays. M18A can be reconstructed with `src/reproducibility/rebuild_m18a.py`. Exact hashes are in `data/PARENT_SHA256SUMS.txt`.

## Manuscripts

```bash
make manuscript
make verify
```

The manuscript target starts with `latexmk -C`, so the final log is clean. Kepler count reconciliation is in `data/KEPLER_COUNT_RECONCILIATION.json`.
