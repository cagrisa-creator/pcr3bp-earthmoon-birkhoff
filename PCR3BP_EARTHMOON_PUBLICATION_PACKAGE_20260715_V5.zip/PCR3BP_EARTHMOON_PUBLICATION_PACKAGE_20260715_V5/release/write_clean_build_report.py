#!/usr/bin/env python3
from pathlib import Path
import datetime, json, re, subprocess, sys
root=Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve()
errors=[]; reports={}
patterns=[r'undefined references',r'Citation .+ undefined',r'There were undefined references',r'Empty bibliography',r'Please \(re\)run Biber',r'Fatal error',r'Emergency stop',r'LaTeX Error:']
for lang,stem in [('en','earth_moon_pcr3bp_en'),('pt','earth_moon_pcr3bp_pt')]:
 d=root/'paper'/lang; log=d/f'{stem}.log'; pdf=d/f'{stem}.pdf'; bbl=d/f'{stem}.bbl'
 if not all(p.is_file() for p in [log,pdf,bbl]):
  errors.append(f'missing_build_output:{lang}'); continue
 text=log.read_text(errors='replace')
 hits=[pat for pat in patterns if re.search(pat,text,re.I)]
 if hits: errors.extend(f'{lang}:{x}' for x in hits)
 info=subprocess.run(['pdfinfo',str(pdf)],capture_output=True,text=True,check=True).stdout
 pages=re.search(r'^Pages:\s+(\d+)',info,re.M).group(1)
 report=(
  'CLEAN LATEX BUILD PASS\n'
  f'language: {lang}\n'
  f'generated_utc: {datetime.datetime.now(datetime.timezone.utc).isoformat()}\n'
  f'pdf: {pdf.name}\n'
  f'pages: {pages}\n'
  'bibliography: Biber PASS\n'
  'undefined_citations: 0\n'
  'undefined_references: 0\n'
  'fatal_errors: 0\n'
 )
 (d/'latex_build.log').write_text(report)
 reports[lang]={'pages':int(pages),'status':'PASS'}
print(json.dumps({'reports':reports,'errors':errors,'status':'PASS' if not errors else 'FAIL'},indent=2))
sys.exit(0 if not errors else 1)
