# Fields to replace

- Author affiliation: xxxxx
- Email: xxxxx
- ORCID: xxxxx
- GitHub URL: xxxxx
- Zenodo URL: xxxxx
- Article DOI: xxxxx
- Software DOI: xxxxx
- Journal: xxxxx
- Funding: xxxxx
- Acknowledgments: xxxxx
- License: xxxxx
- Release version/date: xxxxx
