#!/usr/bin/env python3
from pathlib import Path
import sys
root=Path(sys.argv[1] if len(sys.argv)>1 else '.')
allow={'README.md','CITATION.cff','.zenodo.json','METADATA_TO_FILL.md','COVER_LETTER_EN.docx','COVER_LETTER_PT.docx'}
found=[]
for p in root.rglob('*'):
    if p.is_file() and p.suffix.lower() in {'.tex','.md','.json','.yml','.yaml','.cff','.txt'}:
        try:t=p.read_text(encoding='utf-8')
        except:continue
        if 'xxxxx' in t: found.append(str(p))
print('PLACEHOLDER_FILES')
for p in found: print(p)
print('COUNT',len(found))
