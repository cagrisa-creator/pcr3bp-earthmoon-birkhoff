# Earth-Moon PCR3BP publication package - corrected version 2

This package contains the English and Portuguese manuscripts, LaTeX and DOCX sources, bibliography, reproducibility code, GitHub/Zenodo metadata templates, cover letters, release checks, and the corrections audit.

## Main result

For the physical Earth-Moon mass ratio, the bounded lunar component is certified globally strictly convex after exact antipodal symplectic transformations for every regular subcritical energy `c > c_L1`, where

`c_L1 in [1.5941705588746069, 1.5941705588746333]`.

The contact-topological consequence is a rational disk-like global surface of section bound by Birkhoff's retrograde orbit.

## Verification

```bash
make manuscript
make verify
make verify-parents PARENTS=/path/to/archival-parents
```

The symbolic scripts now resolve `src/core/outer_dynamic.cpp` correctly in a clean checkout. Clean LaTeX build reports contain no unresolved citations or references. The Kepler leaf-count reconciliation is in `data/KEPLER_COUNT_RECONCILIATION.json`.

## Metadata to fill before deposition

GitHub, Zenodo, DOI, ORCID, affiliation, email, funding, acknowledgments, version tag, and license remain marked by the tracked metadata placeholders.

## Submission gate

The signed independent review in `private_review/HUMAN_VERIFICATION_CHECKLIST_PRIVATE.md` is mandatory before submission or arXiv posting, especially its contact-topological items 7-9.
