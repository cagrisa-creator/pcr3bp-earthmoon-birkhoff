# Submission checklist

- [ ] Obtain the signed independent review; items 7–9 are mandatory contact-topological gates.
- [ ] Resolve every reviewer correction.
- [ ] Replace every `xxxxx`.
- [ ] Insert journal style/class and verify author metadata.
- [ ] Run `make manuscript` and `make verify` in a clean environment.
- [ ] Verify all external parent hashes and verifiers.
- [ ] Deposit GitHub and Zenodo releases and insert DOI.
- [ ] Confirm bibliography, theorem numbering, and figure permissions.
- [ ] Upload manuscript, cover letter, supplementary code, and data statement.
