#include <boost/numeric/interval.hpp>
#include <boost/numeric/interval/transc.hpp>
#include <cmath>
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <sstream>
#include <string>
#include <vector>
#include <algorithm>
using namespace boost::numeric;
using Rnd=interval_lib::save_state<interval_lib::rounded_transc_std<double>>;
using Pol=interval_lib::policies<Rnd,interval_lib::checking_base<double>>;
using I=interval<double,Pol>;
static double lo(const I&x){return lower(x);} static double hi(const I&x){return upper(x);} 
static I exactdouble(double d){return I(std::nextafter(d,-INFINITY),std::nextafter(d,INFINITY));}
static I intervaldec(const std::string&a,const std::string&b){double x=strtod(a.c_str(),0),y=strtod(b.c_str(),0);return I(std::nextafter(x,-INFINITY),std::nextafter(y,INFINITY));}
static I MU=intervaldec("0.987849414390376","0.987849414390376");
static I CC=intervaldec("1.70","1.75");
static double CDOUBLE=1.725;
static I AA=exactdouble(0.5);
static constexpr int N=10; static const int ex[N]={0,1,0,2,1,0,3,2,1,0}; static const int ey[N]={0,0,1,0,1,2,0,1,2,3};
static int idx(int a,int b){for(int k=0;k<N;k++)if(ex[k]==a&&ey[k]==b)return k;return -1;}
struct P{I c[N];P(){for(int k=0;k<N;k++)c[k]=I(0);}explicit P(const I&v):P(){c[0]=v;}static P X(const I&v){P p(v);p.c[idx(1,0)]=I(1);return p;}static P Y(const I&v){P p(v);p.c[idx(0,1)]=I(1);return p;}};
static P operator+(const P&a,const P&b){P z;for(int k=0;k<N;k++)z.c[k]=a.c[k]+b.c[k];return z;} static P operator-(const P&a,const P&b){P z;for(int k=0;k<N;k++)z.c[k]=a.c[k]-b.c[k];return z;} static P operator-(const P&a){P z;for(int k=0;k<N;k++)z.c[k]=-a.c[k];return z;} static P operator*(const P&a,const P&b){P z;for(int k=0;k<N;k++)for(int l=0;l<N;l++){int q=idx(ex[k]+ex[l],ey[k]+ey[l]);if(q>=0)z.c[q]+=a.c[k]*b.c[l];}return z;} static P invp(const P&a){P b;b.c[0]=I(1)/a.c[0];for(int deg=1;deg<=3;deg++)for(int k=0;k<N;k++)if(ex[k]+ey[k]==deg){I s=I(0);for(int l=1;l<N;l++)if(ex[l]<=ex[k]&&ey[l]<=ey[k]){int q=idx(ex[k]-ex[l],ey[k]-ey[l]);if(q>=0)s+=a.c[l]*b.c[q];}b.c[k]=-s/a.c[0];}return b;} static P operator/(const P&a,const P&b){return a*invp(b);} static P sqrtp(const P&a){P b;b.c[0]=sqrt(a.c[0]);for(int deg=1;deg<=3;deg++)for(int k=0;k<N;k++)if(ex[k]+ey[k]==deg){I s=I(0);for(int l=1;l<N;l++)if(ex[l]<=ex[k]&&ey[l]<=ey[k]){int q=idx(ex[k]-ex[l],ey[k]-ey[l]);if(q>=0)s+=b.c[l]*b.c[q];}b.c[k]=(a.c[k]-s)/(I(2)*b.c[0]);}return b;} static P powi(P a,int n){P z(I(1));for(int j=0;j<n;j++)z=z*a;return z;}
static P fpoly(const P&x,const P&y){P s=x*x+y*y;P d=P(I(1))-P(I(4))*(x*x-y*y)+P(I(4))*s*s;return P(I(1))-P(MU)+P(I(2)*MU)*s/sqrtp(d)-P(I(2)*CC)*s+P(MU*MU)*s+P(I(4))*powi(s,3)-P(I(4)*MU)*s*(x*x-y*y);} 
static I fscalar(const I&r,const I&t){I x=r*cos(t),y=r*sin(t),s=x*x+y*y,d=I(1)-I(4)*(x*x-y*y)+I(4)*s*s;return I(1)-MU+I(2)*MU*s/sqrt(d)-I(2)*CC*s+MU*MU*s+I(4)*s*s*s-I(4)*MU*s*(x*x-y*y);} 
static double fdouble(double r,double t){const double mu=.987849414390376,c=CDOUBLE;double x=r*cos(t),y=r*sin(t),s=x*x+y*y,d=1-4*(x*x-y*y)+4*s*s;return 1-mu+2*mu*s/std::sqrt(d)-2*c*s+mu*mu*s+4*s*s*s-4*mu*s*(x*x-y*y);} 
static bool collarBracket(const I&t,const I&A,I&rl,I&ru){
 double tc=.5*(lo(t)+hi(t)), ac=std::max(0.,.5*(lo(A)+hi(A))), target=ac*ac;
 // On the compact lunar branch throughout c in [1.5977,1.5989],
 // F(0)-A^2 >= 0 and F(0.275)-A^2 < 0. The first physical root is
 // the unique crossing in [0,0.275]. This fixed bracket avoids the
 // expensive 1200-point scan used by the S4 prototype.
 double L=0.0, R=0.275;
 double fL=fdouble(L,tc)-target, fR=fdouble(R,tc)-target;
 if(!(fL>=0 && fR<0)) return false;
 for(int k=0;k<90;k++){double m=.5*(L+R);if(fdouble(m,tc)-target>0)L=m;else R=m;}
 double seed=.5*(L+R),w=1e-12;I aa=A*A;
 for(int k=0;k<120;k++){double l=std::max(0.,seed-w),u=std::min(.275,seed+w);I fl=fscalar(exactdouble(l),t)-aa,fu=fscalar(exactdouble(u),t)-aa;if((l==0.||lo(fl)>0)&&hi(fu)<0){rl=exactdouble(l);ru=exactdouble(u);return true;}w*=1.8;}return false;}


struct D2{I f,fx,fy,fxx,fxy,fyy;}; static I midpt(const I&x){return I(.5*(lo(x)+hi(x)));}
static D2 mvt(const I&X,const I&Y){I x0=midpt(X),y0=midpt(Y);P p0=fpoly(P::X(x0),P::Y(y0)),p=fpoly(P::X(X),P::Y(Y));I dx=X-x0,dy=Y-y0;I F0=p0.c[0],Fx0=p0.c[idx(1,0)],Fy0=p0.c[idx(0,1)],Fxx0=I(2)*p0.c[idx(2,0)],Fxy0=p0.c[idx(1,1)],Fyy0=I(2)*p0.c[idx(0,2)];I Fx=p.c[idx(1,0)],Fy=p.c[idx(0,1)],Fxx=I(2)*p.c[idx(2,0)],Fxy=p.c[idx(1,1)],Fyy=I(2)*p.c[idx(0,2)],Fxxx=I(6)*p.c[idx(3,0)],Fxxy=I(2)*p.c[idx(2,1)],Fxyy=I(2)*p.c[idx(1,2)],Fyyy=I(6)*p.c[idx(0,3)];D2 d;d.f=F0+Fx*dx+Fy*dy;d.fx=Fx0+Fxx*dx+Fxy*dy;d.fy=Fy0+Fxy*dx+Fyy*dy;d.fxx=Fxx0+Fxxx*dx+Fxxy*dy;d.fxy=Fxy0+Fxxy*dx+Fxyy*dy;d.fyy=Fyy0+Fxyy*dx+Fyyy*dy;return d;}

static I sqrI(const I&x){double l=lo(x),u=hi(x);if(l>=0||u<=0)return x*x;double m=std::max(l*l,u*u);return I(0,std::nextafter(m,INFINITY));}
struct Cell{double t0,t1,a0,a1;};
struct Stat{long tested=0,pass=0,fail=0,sub=0;double ming2=1e100,mingersh=1e100,mindet=1e100;};
static bool pos3(I B[3][3],double &glb,double &detlb){
 for(int i=0;i<3;i++)for(int j=i+1;j<3;j++){double l=std::max(lo(B[i][j]),lo(B[j][i])),u=std::min(hi(B[i][j]),hi(B[j][i]));if(l>u)return false;B[i][j]=B[j][i]=I(l,u);} 
 double bm[3][3];for(int i=0;i<3;i++)for(int j=0;j<3;j++)bm[i][j]=.5*(lo(B[i][j])+hi(B[i][j]));
 double L[3][3]={{0}};if(bm[0][0]<=0)return false;L[0][0]=std::sqrt(bm[0][0]);L[1][0]=bm[1][0]/L[0][0];L[2][0]=bm[2][0]/L[0][0];double d1=bm[1][1]-L[1][0]*L[1][0];if(d1<=0)return false;L[1][1]=std::sqrt(d1);L[2][1]=(bm[2][1]-L[2][0]*L[1][0])/L[1][1];double d2=bm[2][2]-L[2][0]*L[2][0]-L[2][1]*L[2][1];if(d2<=0)return false;L[2][2]=std::sqrt(d2);
 double Li[3][3]={{0}};for(int col=0;col<3;col++)for(int i=0;i<3;i++){double rhs=(i==col);for(int j=0;j<i;j++)rhs-=L[i][j]*Li[j][col];Li[i][col]=rhs/L[i][i];}
 double R[3][3];for(int i=0;i<3;i++)for(int j=0;j<3;j++)R[i][j]=Li[j][i];
 I C[3][3];for(int i=0;i<3;i++)for(int j=0;j<3;j++){C[i][j]=I(0);for(int r=0;r<3;r++)for(int s=0;s<3;s++)C[i][j]+=exactdouble(R[r][i])*B[r][s]*exactdouble(R[s][j]);}
 glb=1e100;for(int i=0;i<3;i++){double rad=0;for(int j=0;j<3;j++)if(i!=j)rad+=std::max(std::abs(lo(C[i][j])),std::abs(hi(C[i][j])));glb=std::min(glb,lo(C[i][i])-rad);} 
 I det=B[0][0]*(B[1][1]*B[2][2]-B[1][2]*B[2][1])-B[0][1]*(B[1][0]*B[2][2]-B[1][2]*B[2][0])+B[0][2]*(B[1][0]*B[2][1]-B[1][1]*B[2][0]);detlb=lo(det);return glb>0;
}
static bool eval(const Cell&q,int maxphi,Stat&S){
 I T(std::nextafter(q.t0,-INFINITY),std::nextafter(q.t1,INFINITY)),A(std::nextafter(q.a0,-INFINITY),std::nextafter(q.a1,INFINITY)),rl,ru;
 if(!collarBracket(T,A,rl,ru))return false;I r(lo(rl),hi(ru)),X=r*cos(T),Y=r*sin(T);I aa=A*A;I fl=fscalar(rl,T)-aa,fu=fscalar(ru,T)-aa;if(!(lo(fl)>0&&hi(fu)<0))return false;
 D2 z=mvt(X,Y);I g2=sqrI(z.fx)+sqrI(z.fy);S.ming2=std::min(S.ming2,lo(g2));if(lo(g2)<=0)return false;
 I ss=sqrI(X)+sqrI(Y);I b[2]={-(I(2)*ss+MU)*Y,(I(2)*ss-MU)*X};
 I Pm[2][2]={{-I(4)*X*Y,-I(2)*sqrI(X)-I(6)*sqrI(Y)-MU},{I(6)*sqrI(X)+I(2)*sqrI(Y)-MU,I(4)*X*Y}};
 I B1[2][2]={{-I(4)*Y,-I(4)*X},{-I(4)*X,-I(12)*Y}},B2[2][2]={{I(12)*X,I(4)*Y},{I(4)*Y,I(4)*X}};
 I Fh[2][2]={{z.fxx,z.fxy},{z.fxy,z.fyy}};
 const I PI=I(4)*atan(I(1));
 struct PS{double l,u;int d;}; std::vector<PS> stack;
 const int base=8; int maxd=0; while((base<<maxd)<maxphi)maxd++;
 for(int k=0;k<base;k++)stack.push_back({2.0*M_PI*k/base,2.0*M_PI*(k+1)/base,0});
 bool all=true;
 while(!stack.empty()){
  PS ps=stack.back();stack.pop_back();I ph(std::nextafter(ps.l,-INFINITY),std::nextafter(ps.u,INFINITY)),cp=cos(ph),sp=sin(ph);
  I u[2]={A*cp,A*sp};I p[2]={u[0]-b[0],u[1]-b[1]};
  I gq[2]={Pm[0][0]*u[0]+Pm[1][0]*u[1]-z.fx/I(2),Pm[0][1]*u[0]+Pm[1][1]*u[1]-z.fy/I(2)};
  I R1[2][2]={{I(6)*AA*p[1],I(6)*AA*p[0]},{I(6)*AA*p[0],-I(6)*AA*p[1]}},R2[2][2]={{I(6)*AA*p[0],-I(6)*AA*p[1]},{-I(6)*AA*p[1],-I(6)*AA*p[0]}};
  I Rm[2][2],Mm[2][2],Lm[2][2],RP[2][2],Cm[2][2];
  for(int i=0;i<2;i++)for(int j=0;j<2;j++){Rm[i][j]=gq[0]*R1[i][j]+gq[1]*R2[i][j];Mm[i][j]=Rm[i][j]+I(i==j);Lm[i][j]=u[0]*B1[i][j]+u[1]*B2[i][j]-Fh[i][j]/I(2);RP[i][j]=I(0);for(int k=0;k<2;k++)RP[i][j]+=Rm[i][k]*Pm[k][j];}
  for(int i=0;i<2;i++)for(int j=0;j<2;j++){Cm[i][j]=Lm[i][j];for(int k=0;k<2;k++)Cm[i][j]+=Pm[k][i]*RP[k][j];}
  Rm[1][0]=Rm[0][1];Mm[1][0]=Mm[0][1];Lm[1][0]=Lm[0][1];Cm[1][0]=Cm[0][1];
  I Q[4][4];for(int i=0;i<4;i++)for(int j=0;j<4;j++)Q[i][j]=I(0);for(int i=0;i<2;i++)for(int j=0;j<2;j++){Q[i][j]=Mm[i][j];Q[i][2+j]=-RP[i][j];Q[2+j][i]=-RP[i][j];Q[2+i][2+j]=Cm[i][j];}
  I W[4][3]={{-sp,cp,I(0)},{cp,sp,I(0)},{I(0),I(2)*A*z.fx/g2,-z.fy},{I(0),I(2)*A*z.fy/g2,z.fx}};
  I Br[3][3];for(int i=0;i<3;i++)for(int j=i;j<3;j++){I zsum=I(0);for(int m=0;m<4;m++)for(int n=0;n<4;n++)zsum+=W[m][i]*Q[m][n]*W[n][j];Br[i][j]=Br[j][i]=zsum;}
  double glb,detlb;if(pos3(Br,glb,detlb)){S.mingersh=std::min(S.mingersh,glb);S.mindet=std::min(S.mindet,detlb);continue;}
  if(ps.d>=maxd){all=false;S.mingersh=std::min(S.mingersh,glb);S.mindet=std::min(S.mindet,detlb);continue;}
  double m=.5*(ps.l+ps.u);stack.push_back({ps.l,m,ps.d+1});stack.push_back({m,ps.u,ps.d+1});
 }
 return all;
}

static std::vector<Cell> splitTheta(const Cell&q){double tm=.5*(q.t0+q.t1);return {{q.t0,tm,q.a0,q.a1},{tm,q.t1,q.a0,q.a1}};}
static void add(Stat&a,const Stat&b){a.tested+=b.tested;a.pass+=b.pass;a.fail+=b.fail;a.sub+=b.sub;a.ming2=std::min(a.ming2,b.ming2);a.mingersh=std::min(a.mingersh,b.mingersh);a.mindet=std::min(a.mindet,b.mindet);} 
static bool adaptive(const Cell&q,int np,int d,int md,Stat&o){Stat s;s.tested=1;if(eval(q,np,s)){s.pass=s.sub=1;add(o,s);return true;}if(d>=md){s.fail=1;add(o,s);return false;}Stat k;bool ok=true;for(auto z:splitTheta(q))ok=adaptive(z,np,d+1,md,k)&&ok;add(o,k);return ok;}
int main(int ac,char**av){if(ac<4)return 2;double c0=atof(av[2]),c1=atof(av[3]);CC=I(std::nextafter(c0,-INFINITY),std::nextafter(c1,INFINITY));CDOUBLE=.5*(c0+c1);int np=ac>4?atoi(av[4]):128,md=ac>5?atoi(av[5]):5;std::ifstream in(av[1]);std::vector<Cell>v;Cell q;while(in>>q.t0>>q.t1>>q.a0>>q.a1)v.push_back(q);Stat S;long failboxes=0;for(size_t i=0;i<v.size();i++){Stat one;bool ok=adaptive(v[i],np,0,md,one);add(S,one);if(!ok){failboxes++;if(failboxes<=100)std::cerr<<"FAIL "<<i<<" box "<<v[i].t0<<" "<<v[i].t1<<" "<<v[i].a0<<" "<<v[i].a1<<" gersh="<<one.mingersh<<"\n";}if(i%1000==0)std::cerr<<"progress "<<i<<" failboxes="<<failboxes<<" sub="<<S.sub<<" g="<<S.mingersh<<"\n";}
 std::cout<<std::setprecision(17)<<"HORIZONTAL_SHEAR_REDUCED_OUTER_GATE\nmu=0.987849414390376\nc=["<<c0<<","<<c1<<"]\na=0.5\nboxes="<<v.size()<<" tested="<<S.tested<<" pass="<<S.pass<<" fail="<<S.fail<<" leaves="<<S.sub<<"\nmin_fgrad2="<<S.ming2<<"\nmin_preconditioned_gersh="<<S.mingersh<<"\nmin_raw_det="<<S.mindet<<"\nSTATUS="<<(S.fail?"FAIL":"PASS")<<"\n";return S.fail?1:0;}
