#include <boost/numeric/interval.hpp>
#include <boost/numeric/interval/transc.hpp>
#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <limits>
#include <string>
using namespace boost::numeric;
using Rnd=interval_lib::save_state<interval_lib::rounded_transc_std<double>>;
using Pol=interval_lib::policies<Rnd,interval_lib::checking_base<double>>;
using I=interval<double,Pol>;
static double lo(const I&x){return lower(x);} static double hi(const I&x){return upper(x);}
static I dec(const char*a,const char*b){double x=strtod(a,nullptr),y=strtod(b,nullptr);return I(std::nextafter(x,-INFINITY),std::nextafter(y,INFINITY));}
static I point(double x){return I(std::nextafter(x,-INFINITY),std::nextafter(x,INFINITY));}
static I M=dec("0.987849414390376","0.987849414390376");
static I CMIN=dec("1.82","1.82");
static I SMAX=dec("0.026","0.026");
static I sqr(const I&x){double a=lo(x),b=hi(x);if(a>=0||b<=0)return x*x;return I(0,std::nextafter(std::max(a*a,b*b),INFINITY));}

// Degree-3 bivariate interval Taylor polynomial, copied from the finite certificate.
static constexpr int N=10; static const int ex[N]={0,1,0,2,1,0,3,2,1,0}; static const int ey[N]={0,0,1,0,1,2,0,1,2,3};
static int idx(int a,int b){for(int k=0;k<N;k++)if(ex[k]==a&&ey[k]==b)return k;return -1;}
struct P{I c[N];P(){for(auto &v:c)v=I(0);}explicit P(const I&v):P(){c[0]=v;}static P X(const I&v){P p(v);p.c[idx(1,0)]=I(1);return p;}static P Y(const I&v){P p(v);p.c[idx(0,1)]=I(1);return p;}};
static P operator+(const P&a,const P&b){P z;for(int k=0;k<N;k++)z.c[k]=a.c[k]+b.c[k];return z;}
static P operator-(const P&a,const P&b){P z;for(int k=0;k<N;k++)z.c[k]=a.c[k]-b.c[k];return z;}
static P operator-(const P&a){P z;for(int k=0;k<N;k++)z.c[k]=-a.c[k];return z;}
static P operator*(const P&a,const P&b){P z;for(int k=0;k<N;k++)for(int l=0;l<N;l++){int q=idx(ex[k]+ex[l],ey[k]+ey[l]);if(q>=0)z.c[q]+=a.c[k]*b.c[l];}return z;}
static P invp(const P&a){P b;b.c[0]=I(1)/a.c[0];for(int d=1;d<=3;d++)for(int k=0;k<N;k++)if(ex[k]+ey[k]==d){I s=I(0);for(int l=1;l<N;l++)if(ex[l]<=ex[k]&&ey[l]<=ey[k]){int q=idx(ex[k]-ex[l],ey[k]-ey[l]);if(q>=0)s+=a.c[l]*b.c[q];}b.c[k]=-s/a.c[0];}return b;}
static P operator/(const P&a,const P&b){return a*invp(b);} static P sqrtp(const P&a){P b;b.c[0]=sqrt(a.c[0]);for(int d=1;d<=3;d++)for(int k=0;k<N;k++)if(ex[k]+ey[k]==d){I s=I(0);for(int l=1;l<N;l++)if(ex[l]<=ex[k]&&ey[l]<=ey[k]){int q=idx(ex[k]-ex[l],ey[k]-ey[l]);if(q>=0)s+=b.c[l]*b.c[q];}b.c[k]=(a.c[k]-s)/(I(2)*b.c[0]);}return b;}
static P powi(P a,int n){P z(I(1));for(int j=0;j<n;j++)z=z*a;return z;}
static P fpoly(const P&x,const P&y){P s=x*x+y*y;P d=P(I(1))-P(I(4))*(x*x-y*y)+P(I(4))*s*s;return P(I(1))-P(M)+P(I(2)*M)*s/sqrtp(d)-P(I(2)*CMIN)*s+P(M*M)*s+P(I(4))*powi(s,3)-P(I(4)*M)*s*(x*x-y*y);}
static I mid(const I&x){return I(.5*(lo(x)+hi(x)));}
struct D2{I f,fx,fy,fxx,fxy,fyy;};
static D2 mvt(const I&X,const I&Y){I x0=mid(X),y0=mid(Y);P p0=fpoly(P::X(x0),P::Y(y0)),p=fpoly(P::X(X),P::Y(Y));I dx=X-x0,dy=Y-y0;I F0=p0.c[0],Fx0=p0.c[idx(1,0)],Fy0=p0.c[idx(0,1)],Fxx0=I(2)*p0.c[idx(2,0)],Fxy0=p0.c[idx(1,1)],Fyy0=I(2)*p0.c[idx(0,2)];I Fx=p.c[idx(1,0)],Fy=p.c[idx(0,1)],Fxx=I(2)*p.c[idx(2,0)],Fxy=p.c[idx(1,1)],Fyy=I(2)*p.c[idx(0,2)],Fxxx=I(6)*p.c[idx(3,0)],Fxxy=I(2)*p.c[idx(2,1)],Fxyy=I(2)*p.c[idx(1,2)],Fyyy=I(6)*p.c[idx(0,3)];D2 d;d.f=F0+Fx*dx+Fy*dy;d.fx=Fx0+Fxx*dx+Fxy*dy;d.fy=Fy0+Fxy*dx+Fyy*dy;d.fxx=Fxx0+Fxxx*dx+Fxxy*dy;d.fxy=Fxy0+Fxxy*dx+Fxyy*dy;d.fyy=Fyy0+Fxyy*dx+Fyyy*dy;return d;}

static I Fpolar(const I&s,const I&w){I d=I(1)-I(4)*s*w+I(4)*s*s;return I(1)-M+I(2)*M*s/sqrt(d)-I(2)*CMIN*s+M*M*s+I(4)*s*s*s-I(4)*M*s*s*w;}
static I FsPolar(const I&s,const I&w){I d=I(1)-I(4)*s*w+I(4)*s*s;I ds=-I(4)*w+I(8)*s;return I(2)*M/sqrt(d)-M*s*ds/(d*sqrt(d))-I(2)*CMIN+M*M+I(12)*s*s-I(8)*M*s*w;}
static double absmax(const I&x){return std::max(std::abs(lo(x)),std::abs(hi(x)));}
int main(int ac,char**av){
 int NS=ac>1?std::atoi(av[1]):256; int NW=ac>2?std::atoi(av[2]):256; int NXY=ac>3?std::atoi(av[3]):128;
 double max_boundary=-INFINITY,max_fs=-INFINITY; long radial_boxes=0,boundary_boxes=0;
 for(int j=0;j<NW;j++){double a=-1.0+2.0*j/NW,b=-1.0+2.0*(j+1)/NW;I w(std::nextafter(a,-INFINITY),std::nextafter(b,INFINITY));max_boundary=std::max(max_boundary,hi(Fpolar(SMAX,w)));boundary_boxes++;}
 for(int i=0;i<NS;i++){double a=.026*i/NS,b=.026*(i+1)/NS;I s(std::nextafter(a,-INFINITY),std::nextafter(b,INFINITY));for(int j=0;j<NW;j++){double u=-1.0+2.0*j/NW,v=-1.0+2.0*(j+1)/NW;I w(std::nextafter(u,-INFINITY),std::nextafter(v,INFINITY));max_fs=std::max(max_fs,hi(FsPolar(s,w)));radial_boxes++;}}
 bool stage1=max_boundary<0 && max_fs<0;
 double R=std::sqrt(.026), min00=INFINITY,min11=INFINITY,mindet=INFINITY,mingersh=INFINITY,maxF=-INFINITY;long xy_boxes=0,active=0,skipped_disk=0,skipped_empty=0,failed=0;
 for(int ix=0;ix<NXY;ix++){double xa=-R+2*R*ix/NXY,xb=-R+2*R*(ix+1)/NXY;I X(std::nextafter(xa,-INFINITY),std::nextafter(xb,INFINITY));for(int iy=0;iy<NXY;iy++){double ya=-R+2*R*iy/NXY,yb=-R+2*R*(iy+1)/NXY;I Y(std::nextafter(ya,-INFINITY),std::nextafter(yb,INFINITY));xy_boxes++;I s=sqr(X)+sqr(Y);if(lo(s)>.026){skipped_disk++;continue;}D2 z=mvt(X,Y);maxF=std::max(maxF,hi(z.f));if(hi(z.f)<0){skipped_empty++;continue;}active++;double au=std::sqrt(std::max(0.0,hi(z.f)));I U(std::nextafter(-au,-INFINITY),std::nextafter(au,INFINITY));I B1[2][2]={{-I(4)*Y,-I(4)*X},{-I(4)*X,-I(12)*Y}},B2[2][2]={{I(12)*X,I(4)*Y},{I(4)*Y,I(4)*X}};I H[2][2]={{z.fxx,z.fxy},{z.fxy,z.fyy}};I L[2][2];for(int a=0;a<2;a++)for(int b=0;b<2;b++)L[a][b]=U*B1[a][b]+U*B2[a][b]-H[a][b]/I(2);L[1][0]=L[0][1];I det=L[0][0]*L[1][1]-L[0][1]*L[1][0];double g=std::min(lo(L[0][0])-absmax(L[0][1]),lo(L[1][1])-absmax(L[1][0]));min00=std::min(min00,lo(L[0][0]));min11=std::min(min11,lo(L[1][1]));mindet=std::min(mindet,lo(det));mingersh=std::min(mingersh,g);if(!(lo(L[0][0])>0&&lo(L[1][1])>0&&lo(det)>0))failed++;}}
 bool stage2=failed==0 && min00>0 && min11>0 && mindet>0;
 std::cout<<std::setprecision(17);
 std::cout<<"PCR3BP_EARTHMOON_HIGH_ENERGY_CERT\n";
 std::cout<<"mu=0.987849414390376\n";
 std::cout<<"c_min=1.82\n";
 std::cout<<"s_max=0.026\n";
 std::cout<<"boundary_boxes="<<boundary_boxes<<"\n";
 std::cout<<"max_F_at_smax="<<max_boundary<<"\n";
 std::cout<<"radial_boxes="<<radial_boxes<<"\n";
 std::cout<<"max_dF_ds="<<max_fs<<"\n";
 std::cout<<"stage1="<<(stage1?"PASS":"FAIL")<<"\n";
 std::cout<<"xy_boxes="<<xy_boxes<<"\n";
 std::cout<<"active_boxes="<<active<<"\n";
 std::cout<<"skipped_outside_disk="<<skipped_disk<<"\n";
 std::cout<<"skipped_empty="<<skipped_empty<<"\n";
 std::cout<<"max_F_cmin="<<maxF<<"\n";
 std::cout<<"min_L00="<<min00<<"\n";
 std::cout<<"min_L11="<<min11<<"\n";
 std::cout<<"min_det_L="<<mindet<<"\n";
 std::cout<<"min_gersh_L="<<mingersh<<"\n";
 std::cout<<"failed_boxes="<<failed<<"\n";
 std::cout<<"stage2A="<<(stage2?"PASS":"FAIL")<<"\n";
 std::cout<<"STATUS="<<((stage1&&stage2)?"PASS":"FAIL")<<"\n";
 return (stage1&&stage2)?0:1;
}
