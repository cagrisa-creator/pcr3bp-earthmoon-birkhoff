#!/usr/bin/env python3
import argparse, concurrent.futures as cf, hashlib, json, math, os, pathlib, re, subprocess, sys, time
from collections import defaultdict, deque
from decimal import Decimal, getcontext
getcontext().prec=50
ap=argparse.ArgumentParser()
ap.add_argument('--run-dir',required=True)
ap.add_argument('--row-start',type=int,required=True); ap.add_argument('--row-end',type=int,required=True)
ap.add_argument('--c0',required=True); ap.add_argument('--c1',required=True)
ap.add_argument('--workers',type=int,default=24); ap.add_argument('--max-depth',type=int,default=5)
ap.add_argument('--np',type=int,default=128)
a=ap.parse_args()
run=pathlib.Path(a.run_dir); outdir=run/f'rows{a.row_start:03d}_{a.row_end:03d}'; outdir.mkdir(parents=True,exist_ok=True)
binpath=run/'bin/outer_dynamic_gcc'; inpdir=run/'inputs'
C0=Decimal(a.c0); C1=Decimal(a.c1)

def ds(x:Decimal):
    s=format(x,'f').rstrip('0').rstrip('.')
    return s.replace('-','m').replace('.','p')
def stem(r,c,x0,x1): return f'r{r:03d}_c{c:02d}_{ds(x0)}_{ds(x1)}'
def timeout_for(d): return [30,45,75,120,180,240][min(d,5)]
def parse_out(text):
    vals={}
    patterns={
      'boxes':r'boxes=(\d+)', 'tested':r'tested=(\d+)', 'pass':r'pass=(\d+)', 'fail':r'fail=(\d+)', 'leaves':r'leaves=(\d+)',
      'min_fgrad2':r'min_fgrad2=([^\s]+)', 'min_preconditioned_gersh':r'min_preconditioned_gersh=([^\s]+)', 'min_raw_det':r'min_raw_det=([^\s]+)'}
    for k,p in patterns.items():
        m=re.search(p,text)
        if m:
            vals[k]=int(m.group(1)) if k in {'boxes','tested','pass','fail','leaves'} else float(m.group(1))
    return vals

def input_for(r,c):
    p=inpdir/f'r{r:03d}_c{c:02d}.tsv'
    if not p.exists(): raise FileNotFoundError(p)
    return p

def saved_status(task):
    r,c,x0,x1,d=task; jf=outdir/(stem(r,c,x0,x1)+'.json')
    if not jf.exists(): return None
    try: z=json.loads(jf.read_text())
    except: return None
    return z.get('status')

def run_task(task):
    r,c,x0,x1,d=task; inp=input_for(r,c); st=stem(r,c,x0,x1)
    jf=outdir/(st+'.json'); of=outdir/(st+'.out'); ef=outdir/(st+'.err')
    ih=hashlib.sha256(inp.read_bytes()).hexdigest(); cmd=[str(binpath),str(inp),str(x0),str(x1),str(a.np),'5']
    t=time.time(); raw=''; rc=None
    try:
        p=subprocess.run(cmd,capture_output=True,text=True,timeout=timeout_for(d))
        sec=time.time()-t; rc=p.returncode; of.write_text(p.stdout); ef.write_text(p.stderr); raw='done'
        vals=parse_out(p.stdout)
        ok=(rc==0 and 'STATUS=PASS' in p.stdout and vals.get('fail',0)==0 and vals.get('min_preconditioned_gersh',-1)>0)
        status='pass' if ok else ('split' if d<a.max_depth else 'terminal_fail')
    except subprocess.TimeoutExpired as e:
        sec=time.time()-t; of.write_text(e.stdout.decode() if isinstance(e.stdout,bytes) else (e.stdout or '')); ef.write_text(e.stderr.decode() if isinstance(e.stderr,bytes) else (e.stderr or ''))
        vals={}; raw='timeout'; status='split' if d<a.max_depth else 'terminal_fail'
    rec={'row':r,'col':c,'c0':str(x0),'c1':str(x1),'depth':d,'status':status,'raw_status':raw,'rc':rc,'seconds':sec,
         'input':str(inp),'input_sha256':ih}
    rec.update(vals); jf.write_text(json.dumps(rec,indent=2)+'\n')
    with (run/'run.log').open('a') as f: f.write(json.dumps({**rec,'g':rec.get('min_preconditioned_gersh')})+'\n')
    return rec

def children(t):
    r,c,x0,x1,d=t; m=(x0+x1)/2
    return [(r,c,x0,m,d+1),(r,c,m,x1,d+1)]

def load_tree(r,c,x0,x1,d,tasks,passes,terminal):
    t=(r,c,x0,x1,d); jf=outdir/(stem(r,c,x0,x1)+'.json')
    if not jf.exists(): tasks.append(t); return
    try:z=json.loads(jf.read_text())
    except: tasks.append(t); return
    st=z.get('status')
    if st=='pass': passes[(r,c)].append((x0,x1)); return
    if st=='split' and d<a.max_depth:
        for ch in children(t): load_tree(*ch,tasks,passes,terminal)
    elif st=='terminal_fail': terminal.add((r,c,x0,x1,d))
    else: tasks.append(t)

def covered(ints):
    cur=C0
    for x0,x1 in sorted(ints):
        if x1<=cur: continue
        if x0>cur: return False
        cur=max(cur,x1)
        if cur>=C1:return True
    return cur>=C1

tasks=deque(); passes=defaultdict(list); terminal=set()
for r in range(a.row_start,a.row_end+1):
  for c in range(32): load_tree(r,c,C0,C1,0,tasks,passes,terminal)
covered_cells={k for k,v in passes.items() if covered(v)}
print(json.dumps({'event':'resume','queued':len(tasks),'covered_cells':len(covered_cells),'terminal':len(terminal),'workers':a.workers}),flush=True)
active={}; completed=0
with cf.ThreadPoolExecutor(max_workers=a.workers) as ex:
    while tasks or active:
        while tasks and len(active)<a.workers:
            t=tasks.popleft(); active[ex.submit(run_task,t)]=t
        if not active: break
        done,_=cf.wait(active,return_when=cf.FIRST_COMPLETED)
        for fut in done:
            t=active.pop(fut)
            try: rec=fut.result()
            except Exception as e:
                print(json.dumps({'event':'exception','task':[str(x) for x in t],'error':repr(e)}),flush=True); tasks.append(t); continue
            completed+=1; r,c,x0,x1,d=t
            if rec['status']=='pass':
                passes[(r,c)].append((x0,x1))
                if covered(passes[(r,c)]): covered_cells.add((r,c))
            elif rec['status']=='split':
                for ch in children(t):
                    if saved_status(ch)=='pass':
                        rr,cc,xx0,xx1,dd=ch; passes[(rr,cc)].append((xx0,xx1))
                        if covered(passes[(rr,cc)]): covered_cells.add((rr,cc))
                    else: tasks.append(ch)
            else: terminal.add(t)
            if completed%25==0 or len(covered_cells)==(a.row_end-a.row_start+1)*32:
                gs=[]
                for jf in outdir.glob('r*.json'):
                    try:z=json.loads(jf.read_text())
                    except:continue
                    if z.get('status')=='pass' and isinstance(z.get('min_preconditioned_gersh'),(int,float)):gs.append(z['min_preconditioned_gersh'])
                print(json.dumps({'event':'progress','completed_tasks':completed,'covered_cells':len(covered_cells),'expected':(a.row_end-a.row_start+1)*32,'queued':len(tasks),'active':len(active),'terminal':len(terminal),'min_g':min(gs) if gs else None}),flush=True)
# summary
records=[]
for jf in outdir.glob('r*.json'):
    try:z=json.loads(jf.read_text())
    except:continue
    if z.get('status')=='pass': records.append(z)
covered_cells=set()
by=defaultdict(list)
for z in records: by[(z['row'],z['col'])].append((Decimal(z['c0']),Decimal(z['c1'])))
for k,v in by.items():
    if covered(v): covered_cells.add(k)
summary={'tag':f'E08_R{a.row_start:03d}_{a.row_end:03d}','c0':str(C0),'c1':str(C1),'row_start':a.row_start,'row_end':a.row_end,
 'cells':(a.row_end-a.row_start+1)*32,'runs':sum(1 for _ in outdir.glob('r*.json')),'pass_leaves':len(records),'terminal_failures':len(terminal),
 'covered_cells':len(covered_cells),'boxes':sum(int(z.get('boxes',0)) for z in records),'tested':sum(int(z.get('tested',0)) for z in records),
 'leaves':sum(int(z.get('leaves',0)) for z in records),'min_fgrad2':min((z.get('min_fgrad2',math.inf) for z in records),default=None),
 'min_preconditioned_gersh':min((z.get('min_preconditioned_gersh',math.inf) for z in records),default=None),
 'min_raw_det':min((z.get('min_raw_det',math.inf) for z in records),default=None),
 'status':'PASS' if len(covered_cells)==(a.row_end-a.row_start+1)*32 and not terminal else 'PARTIAL'}
(outdir/'SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'event':'final','summary':summary}),flush=True)
sys.exit(0 if summary['status']=='PASS' else 1)
