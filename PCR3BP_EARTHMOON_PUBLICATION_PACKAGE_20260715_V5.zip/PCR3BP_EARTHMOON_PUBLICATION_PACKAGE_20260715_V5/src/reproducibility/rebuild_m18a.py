#!/usr/bin/env python3
from pathlib import Path
import argparse, hashlib, json, tempfile, zipfile, sys

def sha256_file(path):
    h=hashlib.sha256()
    with path.open("rb") as f:
        for b in iter(lambda:f.read(1<<20),b""):
            h.update(b)
    return h.hexdigest()

parser=argparse.ArgumentParser()
parser.add_argument("parts_dir", type=Path)
parser.add_argument("--output", type=Path, default=Path("PCR3BP_EARTHMOON_ADAPTIVE_MACROBLOCK_M18A_REBUILT_20260711.zip"))
args=parser.parse_args()
root=Path(__file__).resolve().parents[1]
manifest=json.loads((root/"04_M18A_RECOVERY/M18A_PARTS_MANIFEST.json").read_text())
errors=[]
fragments=[]

with tempfile.TemporaryDirectory() as td:
    tdir=Path(td)
    for item in manifest["parts"]:
        wrapper=args.parts_dir/item["wrapper"]
        if not wrapper.is_file():
            errors.append("missing:"+item["wrapper"])
            continue
        if wrapper.stat().st_size!=item["wrapper_size"]:
            errors.append("wrapper_size:"+item["wrapper"])
        if sha256_file(wrapper)!=item["wrapper_sha256"]:
            errors.append("wrapper_sha256:"+item["wrapper"])
            continue
        with zipfile.ZipFile(wrapper) as zf:
            bad=zf.testzip()
            if bad:
                errors.append("wrapper_crc:"+item["wrapper"]+":"+bad)
                continue
            names=[n for n in zf.namelist() if not n.endswith("/")]
            if len(names)!=1:
                errors.append("wrapper_members:"+item["wrapper"])
                continue
            target=tdir/item["inner"]
            target.write_bytes(zf.read(names[0]))
        if target.stat().st_size!=item["fragment_size"]:
            errors.append("fragment_size:"+item["inner"])
        if sha256_file(target)!=item["fragment_sha256"]:
            errors.append("fragment_sha256:"+item["inner"])
        fragments.append(target)
    if errors:
        print(json.dumps({"status":"FAIL","errors":errors},indent=2))
        sys.exit(1)
    with args.output.open("wb") as out:
        for p in fragments:
            with p.open("rb") as f:
                for b in iter(lambda:f.read(1<<20),b""):
                    out.write(b)

source=manifest["source"]
if args.output.stat().st_size!=source["size_bytes"]:
    errors.append("source_size")
if sha256_file(args.output)!=source["sha256"]:
    errors.append("source_sha256")
try:
    with zipfile.ZipFile(args.output) as zf:
        bad=zf.testzip()
        if bad: errors.append("source_crc:"+bad)
except Exception as exc:
    errors.append("source_zip:"+str(exc))

print(json.dumps({
    "output":str(args.output),
    "bytes":args.output.stat().st_size if args.output.exists() else None,
    "sha256":sha256_file(args.output) if args.output.exists() else None,
    "errors":errors,
    "status":"PASS" if not errors else "FAIL"
},indent=2))
sys.exit(0 if not errors else 1)
