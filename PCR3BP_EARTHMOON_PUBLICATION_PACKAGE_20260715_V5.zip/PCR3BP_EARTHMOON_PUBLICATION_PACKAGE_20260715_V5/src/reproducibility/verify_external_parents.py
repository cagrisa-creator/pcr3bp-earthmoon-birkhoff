#!/usr/bin/env python3
from pathlib import Path
import argparse, hashlib, io, json, sys, zipfile

root = Path(__file__).resolve().parents[1]
registry = json.loads((root/"02_PARENT_REGISTRY/PARENTS.json").read_text())

def sha256_file(path):
    h=hashlib.sha256()
    with path.open("rb") as f:
        for b in iter(lambda:f.read(1<<20),b""): h.update(b)
    return h.hexdigest()

def find_by_hash(folder, expected):
    candidates=[]
    for p in folder.rglob("*"):
        if p.is_file() and p.suffix.lower() in {".zip",".bin"}:
            try:
                if sha256_file(p)==expected: return p
            except OSError:
                pass
    return None

def read_unique_json(zf, suffix):
    names=[n for n in zf.namelist() if n.endswith(suffix)]
    if len(names)!=1: raise RuntimeError(f"{suffix}: found {len(names)}")
    return json.loads(zf.read(names[0]))

parser=argparse.ArgumentParser()
parser.add_argument("parents_dir",type=Path)
args=parser.parse_args()
errors=[]; found={}

for key,item in registry.items():
    p=find_by_hash(args.parents_dir,item["sha256"])
    if p is None:
        errors.append("missing_hash:"+key+":"+item["sha256"]); continue
    found[key]=str(p)
    try:
        with zipfile.ZipFile(p) as z:
            bad=z.testzip()
            if bad: errors.append("crc:"+key+":"+bad)
            if key=="L1_BRIDGE":
                s=read_unique_json(z,"/00_READ_FIRST/MASTER_STATUS.json")
                if s.get("status")!="L1_CRITICAL_BRIDGE_MASTER_PASS": errors.append("status:L1")
            elif key=="S17":
                s=read_unique_json(z,"/08_LEDGERS/FULL_S17_SUMMARY.json")
                if s.get("status")!="PASS" or s.get("fail_total")!=0: errors.append("status:S17")
            elif key=="M18A":
                s=read_unique_json(z,"/00_READ_FIRST/FINAL_STATUS.json")
                a=read_unique_json(z,"/06_AUDIT/full_audit.json")
                g=read_unique_json(z,"/06_AUDIT/source_generation_audit.json")
                if s.get("status")!="M18A_REBUILT_CHECKPOINT_PASS": errors.append("status:M18A")
                if a.get("status")!="FULL_AUDIT_PASS" or a.get("error_count")!=0: errors.append("audit:M18A")
                if g.get("status")!="SOURCE_GENERATION_AUDIT_PASS" or g.get("error_count")!=0: errors.append("source:M18A")
            elif key=="GENERAL_MASTER_20260712":
                names=[n for n in z.namelist() if n.endswith("/03_CHECKPOINTS/PCR3BP_EARTHMOON_COMPACT_ATLAS_MASTER_20260711.zip")]
                if len(names)!=1: errors.append("compact_count")
                else:
                    data=z.read(names[0])
                    if hashlib.sha256(data).hexdigest()!=item["contains_compact_master_sha256"]:
                        errors.append("compact_sha")
                    else:
                        with zipfile.ZipFile(io.BytesIO(data)) as c:
                            if c.testzip() is not None: errors.append("compact_crc")
                            s=read_unique_json(c,"/01_CHAIN/MASTER_STATUS.json")
                            if s.get("status")!="COMPACT_ATLAS_MASTER_PASS_WITH_EXTERNAL_PARENT_REFERENCES":
                                errors.append("compact_status")
            elif key=="LOWER_GAP":
                s=read_unique_json(z,"/01_SUMMARY/LOWER_GAP_MASTER_STATUS.json")
                if s.get("status")!="PROMOTED_COMPLETE_LOWER_GAP_PASS" or s.get("rejected")!=0:
                    errors.append("status:LOWER_GAP")
            elif key=="KEPLER":
                s=read_unique_json(z,"/01_STATUS/MASTER_STATUS.json")
                if s.get("status")!="PROMOTED_PASS" or s.get("mathematical_promotion") is not True:
                    errors.append("status:KEPLER")
            elif key=="THEOREM_MAPPING":
                s=read_unique_json(z,"/07_REPRODUCIBILITY/verify_output.json")
                if s.get("status")!="PASS" or s.get("symbolic_status")!="PASS": errors.append("status:THEOREM_MAPPING")
            elif key=="SHEAR_HESSIAN":
                s=read_unique_json(z,"/06_REPRODUCIBILITY/verify_output.json")
                if s.get("status")!="PASS" or s.get("symbolic_status")!="PASS": errors.append("status:SHEAR")
            elif key=="CONDITIONAL_PROOF":
                s=read_unique_json(z,"/06_REPRODUCIBILITY/verify_output.json")
                if s.get("status")!="PASS" or s.get("conditional_theorem_proof")!="COMPLETE":
                    errors.append("status:CONDITIONAL")
    except Exception as exc:
        errors.append("zip:"+key+":"+repr(exc))

out={"checkpoint":root.name,"found":found,"errors":errors,"status":"PASS" if not errors else "FAIL"}
print(json.dumps(out,indent=2,sort_keys=True))
sys.exit(0 if not errors else 1)
