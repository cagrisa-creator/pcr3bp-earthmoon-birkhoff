#!/usr/bin/env python3
import argparse, hashlib, json, math, pathlib, sys
from decimal import Decimal, getcontext
getcontext().prec = 60
ap=argparse.ArgumentParser()
ap.add_argument('result_dir')
ap.add_argument('c0'); ap.add_argument('c1')
ap.add_argument('--row-start',type=int,required=True)
ap.add_argument('--row-end',type=int,required=True)
ap.add_argument('--cols',type=int,default=32)
ap.add_argument('--out',default='EXACT_CELL_AUDIT.json')
a=ap.parse_args()
root=pathlib.Path(a.result_dir); C0=Decimal(a.c0); C1=Decimal(a.c1)
errors=[]; counts={}; by={}; records=[]; terminal=[]
for jf in sorted(root.glob('r*.json')):
    try: d=json.loads(jf.read_text())
    except Exception as e: errors.append(f'JSON_PARSE {jf.name}: {e}'); continue
    if 'row' not in d or 'col' not in d: continue
    r=int(d['row']); c=int(d['col']); st=d.get('status','?')
    counts[st]=counts.get(st,0)+1; by.setdefault((r,c),[]).append((jf,d))
    if st=='terminal_fail': terminal.append(jf.name)
    if st=='pass':
        out=jf.with_suffix('.out'); err=jf.with_suffix('.err')
        if d.get('rc') != 0: errors.append(f'PASS_RC {jf.name}')
        if not out.exists(): errors.append(f'MISSING_OUT {jf.name}')
        else:
            text=out.read_text(errors='replace')
            if 'STATUS=PASS' not in text: errors.append(f'PASS_MARKER {jf.name}')
        if not err.exists(): errors.append(f'MISSING_ERR {jf.name}')
        g=d.get('min_preconditioned_gersh')
        if not isinstance(g,(int,float)) or not math.isfinite(g) or g<=0:
            errors.append(f'NONPOSITIVE_G {jf.name}: {g}')
        if d.get('fail') not in (0,None): errors.append(f'REJECTED_LEAVES {jf.name}: {d.get("fail")}')
        inp=pathlib.Path(d.get('input',''))
        if not inp.exists():
            fallback=root.parent/'inputs'/inp.name
            if fallback.exists(): inp=fallback
        if not inp.exists(): errors.append(f'MISSING_INPUT_SOURCE {jf.name}: {d.get('input','')}')
        elif hashlib.sha256(inp.read_bytes()).hexdigest()!=d.get('input_sha256'):
            errors.append(f'INPUT_HASH {jf.name}')
        records.append((jf,d))
coverage={}; covered=0
for r in range(a.row_start,a.row_end+1):
    for c in range(a.cols):
        ints=[]
        for jf,d in by.get((r,c),[]):
            if d.get('status')!='pass': continue
            try: x0=Decimal(str(d['c0'])); x1=Decimal(str(d['c1']))
            except Exception as e: errors.append(f'BAD_INTERVAL {jf.name}: {e}'); continue
            if not (x0 < x1): errors.append(f'EMPTY_INTERVAL {jf.name}')
            ints.append((x0,x1,jf.name))
        ints.sort(); cur=C0; gaps=[]; overlaps=[]
        for x0,x1,name in ints:
            if x1<=C0 or x0>=C1: continue
            x0=max(x0,C0); x1=min(x1,C1)
            if x0>cur: gaps.append([str(cur),str(x0)])
            if x0<cur and x1>cur: overlaps.append([str(x0),str(cur),name])
            if x0<=cur and x1>cur: cur=x1
            elif x0>cur: cur=x1
            if cur>=C1: break
        if cur<C1: gaps.append([str(cur),str(C1)])
        ok=not gaps
        covered += int(ok)
        coverage[f'r{r:03d}_c{c:02d}']={'covered':ok,'pass_leaf_count':len(ints),'gaps':gaps,'overlaps':overlaps}
expected=(a.row_end-a.row_start+1)*a.cols
if terminal: errors.append(f'TERMINAL_FAILURES {len(terminal)}')
passes=[d for _,d in records]
worst=min(passes,key=lambda d:d.get('min_preconditioned_gersh',float('inf'))) if passes else None
report={
 'status':'PASS' if not errors and covered==expected else 'FAIL',
 'result_dir':str(root),'energy_interval':[str(C0),str(C1)],
 'rows':[a.row_start,a.row_end],'columns':[0,a.cols-1],
 'expected_cells':expected,'covered_cells':covered,'pending_cells':expected-covered,
 'counts':counts,'terminal_failures':len(terminal),'errors':errors,
 'pass_leaves':len(passes),
 'boxes':sum(int(d.get('boxes',0)) for d in passes),
 'tested':sum(int(d.get('tested',0)) for d in passes),
 'accepted':sum(int(d.get('pass',0)) for d in passes),
 'rejected':sum(int(d.get('fail',0)) for d in passes),
 'worst_leaf':worst,
 'coverage':coverage
}
(root/a.out).write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ['status','expected_cells','covered_cells','pending_cells','pass_leaves','terminal_failures','boxes','tested','accepted','rejected','worst_leaf','errors']},indent=2))
sys.exit(0 if report['status']=='PASS' else 1)
