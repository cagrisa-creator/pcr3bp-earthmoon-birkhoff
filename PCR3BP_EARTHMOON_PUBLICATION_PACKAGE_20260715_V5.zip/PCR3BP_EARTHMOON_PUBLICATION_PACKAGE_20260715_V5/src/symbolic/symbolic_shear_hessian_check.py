#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path
import hashlib
import json
import re
import sys

import sympy as sp

root = Path(__file__).resolve().parents[2]
source = root / "src" / "core" / "outer_dynamic.cpp"
expected_source_sha = "b4891f149a9f8590eab87f3c8add18fe1b3be380ebd8214e18a9ff50d00b5c24"

def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()

p1, p2, q1, q2, a = sp.symbols("p1 p2 q1 q2 a", real=True)
u1, u2 = sp.symbols("u1 u2", real=True)
Fx, Fy = sp.symbols("Fx Fy", real=True)
phi, A = sp.symbols("phi A", real=True, nonzero=True)
g1, g2 = sp.symbols("g1 g2", real=True)

p = sp.Matrix([p1, p2])
q = sp.Matrix([q1, q2])

G = a*p1*p2*(p1**2-p2**2)
R = sp.Matrix([sp.diff(G, p1), sp.diff(G, p2)])
DR = R.jacobian(p)
HR1 = sp.hessian(R[0], (p1, p2))
HR2 = sp.hessian(R[1], (p1, p2))

R1_code = sp.Matrix([
    [6*a*p2, 6*a*p1],
    [6*a*p1, -6*a*p2],
])
R2_code = sp.Matrix([
    [6*a*p1, -6*a*p2],
    [-6*a*p2, -6*a*p1],
])

checks = {}
checks["DR_symmetric"] = sp.simplify(DR-DR.T) == sp.zeros(2)
checks["R1_source_matrix"] = sp.simplify(HR1-R1_code) == sp.zeros(2)
checks["R2_source_matrix"] = sp.simplify(HR2-R2_code) == sp.zeros(2)
checks["R_odd"] = sp.simplify(R.subs({p1:-p1,p2:-p2}) + R) == sp.zeros(2,1)
checks["G_even"] = sp.simplify(G.subs({p1:-p1,p2:-p2}) - G) == 0
checks["origin_fixed"] = R.subs({p1:0,p2:0}) == sp.zeros(2,1)

# Symplectic Jacobian for coordinates ordered (p1,p2,q1,q2),
# omega matrix for sum dp_i wedge dq_i.
I2 = sp.eye(2)
Z2 = sp.zeros(2)
Jphi = sp.BlockMatrix([[I2, Z2], [-DR, I2]]).as_explicit()
Omega = sp.BlockMatrix([[Z2, I2], [-I2, Z2]]).as_explicit()
checks["symplectic_jacobian"] = sp.simplify(Jphi.T*Omega*Jphi-Omega) == sp.zeros(4)

# Exactness for lambda=-q.dp: Phi^lambda-lambda = R.dp = dG.
checks["exact_liouville"] = sp.simplify(
    sp.Matrix([sp.diff(G,p1), sp.diff(G,p2)]) - R
) == sp.zeros(2,1)

# Antipodal equivariance.
Phi = sp.Matrix([p1, p2, q1-R[0], q2-R[1]])
Phi_minus = Phi.subs({p1:-p1,p2:-p2,q1:-q1,q2:-q2})
checks["antipodal_equivariance"] = sp.simplify(Phi_minus+Phi) == sp.zeros(4,1)

# Generic source-Hessian bridge.
P11,P12,P21,P22 = sp.symbols("P11 P12 P21 P22", real=True)
L11,L12,L22 = sp.symbols("L11 L12 L22", real=True)
S11,S12,S22 = sp.symbols("S11 S12 S22", real=True)
P = sp.Matrix([[P11,P12],[P21,P22]])
L = sp.Matrix([[L11,L12],[L12,L22]])
S = sp.Matrix([[S11,S12],[S12,S22]])

H0_canonical = sp.BlockMatrix([
    [I2, P],
    [P.T, L+P.T*P],
]).as_explicit()
frame = sp.BlockMatrix([
    [I2, -P],
    [Z2, I2],
]).as_explicit()
base_in_frame = sp.simplify(frame.T*H0_canonical*frame)
checks["un_sheared_frame_diagonalization"] = (
    sp.simplify(base_in_frame-sp.diag(1,1,L11,L22)).subs({L12:0}) == sp.zeros(4)
)
# Use exact block expected rather than the convenience diagonal above.
base_expected = sp.BlockMatrix([[I2,Z2],[Z2,L]]).as_explicit()
checks["un_sheared_frame_exact"] = sp.simplify(base_in_frame-base_expected) == sp.zeros(4)

shear_correction_canonical = sp.BlockMatrix([[S,Z2],[Z2,Z2]]).as_explicit()
correction_in_frame = sp.simplify(frame.T*shear_correction_canonical*frame)
Q_expected = sp.BlockMatrix([
    [I2+S, -S*P],
    [-P.T*S, L+P.T*S*P],
]).as_explicit()
checks["Q_block_identity"] = sp.simplify(
    base_in_frame+correction_in_frame-Q_expected
) == sp.zeros(4)

# Verify the concrete P=Db and Hessians b_i used in the source.
M,x,y = sp.symbols("M x y", real=True)
ss = x**2+y**2
b = sp.Matrix([-(2*ss+M)*y, (2*ss-M)*x])
Db = b.jacobian((x,y))
P_code = sp.Matrix([
    [-4*x*y, -2*x**2-6*y**2-M],
    [6*x**2+2*y**2-M, 4*x*y],
])
B1_code = sp.Matrix([[-4*y,-4*x],[-4*x,-12*y]])
B2_code = sp.Matrix([[12*x,4*y],[4*y,4*x]])
checks["P_equals_Db"] = sp.simplify(Db-P_code) == sp.zeros(2)
checks["B1_equals_Hess_b1"] = sp.simplify(sp.hessian(b[0],(x,y))-B1_code) == sp.zeros(2)
checks["B2_equals_Hess_b2"] = sp.simplify(sp.hessian(b[1],(x,y))-B2_code) == sp.zeros(2)

# Tangent frame W for K=1/2|u|^2-F/2.
cp, spv = sp.symbols("cp sp", real=True)
grad_frame = sp.Matrix([A*cp, A*spv, -Fx/2, -Fy/2])
g_sq = Fx**2+Fy**2
W = sp.Matrix([
    [-spv, cp, 0],
    [ cp, spv, 0],
    [ 0, 2*A*Fx/g_sq, -Fy],
    [ 0, 2*A*Fy/g_sq,  Fx],
])
tangent_products = sp.simplify((grad_frame.T*W).subs(cp**2+spv**2,1))
# SymPy does not automatically use cp^2+sp^2=1 in a matrix expression.
tp = [sp.expand((grad_frame.T*W)[i]) for i in range(3)]
checks["W_col1_tangent"] = sp.simplify(tp[0]) == 0
checks["W_col2_tangent_on_unit_circle"] = sp.simplify(
    tp[1].subs(spv**2,1-cp**2)
) == 0
checks["W_col3_tangent"] = sp.simplify(tp[2]) == 0

# Independence: use the Gram determinant, not one fixed 3x3 minor.
# A fixed minor can vanish when Fx=0 or Fy=0 even though rank(W)=3.
gram_det = sp.factor((W.T*W).det())
gram_on_unit = sp.simplify(gram_det.subs(spv**2, 1-cp**2))
checks["W_gram_identity"] = sp.simplify(
    gram_on_unit - (4*A**2 + g_sq)
) == 0
checks["W_independent_when_A_and_gradF_nonzero"] = checks["W_gram_identity"]

# Source token checks.
src_sha = sha256_file(source)
checks["source_sha256"] = src_sha == expected_source_sha
src = re.sub(r"\s+", "", source.read_text(encoding="utf-8"))
tokens = [
    "staticIAA=exactdouble(0.5);",
    "IR1[2][2]={{I(6)*AA*p[1],I(6)*AA*p[0]},{I(6)*AA*p[0],-I(6)*AA*p[1]}}",
    "R2[2][2]={{I(6)*AA*p[0],-I(6)*AA*p[1]},{-I(6)*AA*p[1],-I(6)*AA*p[0]}}",
    "Mm[i][j]=Rm[i][j]+I(i==j)",
    "Q[i][j]=Mm[i][j]",
    "Q[i][2+j]=-RP[i][j]",
    "Q[2+j][i]=-RP[i][j]",
    "Q[2+i][2+j]=Cm[i][j]",
    "Br[i][j]=Br[j][i]=zsum",
]
checks["source_tokens"] = all(t in src for t in tokens)

result = {
    "status": "PASS" if all(checks.values()) else "FAIL",
    "checks": checks,
    "generator": "G=a*p1*p2*(p1^2-p2^2)",
    "shear": "Phi(p,q)=(p,q-grad G(p))",
    "source_sha256": src_sha,
    "W_gram_determinant_on_unit_circle": str(gram_on_unit),
}
print(json.dumps(result, indent=2, sort_keys=True))
sys.exit(0 if result["status"] == "PASS" else 1)
