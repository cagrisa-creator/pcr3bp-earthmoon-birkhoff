#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path
import hashlib
import json
import re
import sys

import sympy as sp

root = Path(__file__).resolve().parents[2]
source = root / "src" / "core" / "outer_dynamic.cpp"
expected_source_sha = "b4891f149a9f8590eab87f3c8add18fe1b3be380ebd8214e18a9ff50d00b5c24"

def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()

x, y, M, c, wx, wy = sp.symbols("x y M c wx wy", real=True)
delta = 1 - M
s = x**2 + y**2

Q1 = -2 * (x**2 - y**2)
Q2 = -4 * x * y
Q = sp.Matrix([Q1, Q2])
z = sp.Matrix([x, y])
DQ = Q.jacobian(z)

w = sp.Matrix([wx, wy])
p = DQ.T.inv() * w

d = sp.expand((Q1 + 1)**2 + Q2**2)
b = sp.Matrix([-(2*s + M)*y, (2*s - M)*x])

checks = {}

checks["DQ_DQT"] = sp.simplify(DQ * DQ.T - 16*s*sp.eye(2)) == sp.zeros(2)
checks["Q_norm_squared"] = sp.simplify(Q.dot(Q) - 4*s**2) == 0
checks["heavy_distance_squared"] = sp.simplify(
    d - (1 - 4*(x**2-y**2) + 4*s**2)
) == 0
checks["kinetic_identity"] = sp.simplify(
    p.dot(p) - w.dot(w)/(16*s)
) == 0
rot = (Q1 + M)*p[1] - Q2*p[0]
checks["rotation_identity"] = sp.simplify(
    16*s*rot - 4*b.dot(w)
) == 0

b2_expected = M**2*s + 4*s**3 - 4*M*s*(x**2-y**2)
checks["b_norm_identity"] = sp.simplify(b.dot(b) - b2_expected) == 0

F = delta + 2*M*s/sp.sqrt(d) - 2*c*s + b.dot(b)
F_code = (
    1-M
    + 2*M*s/sp.sqrt(1-4*(x**2-y**2)+4*s**2)
    - 2*c*s
    + M**2*s
    + 4*s**3
    - 4*M*s*(x**2-y**2)
)
checks["completed_square_F"] = sp.simplify(F - F_code) == 0

# Full regularized level identity:
# 16s(H+c) = 1/2|w|^2 + 4 b.w -16 M s/sqrt(d) -8 delta +16 c s
lhs_after_shift = (
    sp.Rational(1, 2)*p.dot(p)
    + rot
    - M/sp.sqrt(d)
    - delta/(2*s)
    + c
)
regularized = sp.simplify(16*s*lhs_after_shift)
regularized_expected = (
    sp.Rational(1, 2)*w.dot(w)
    + 4*b.dot(w)
    - 16*M*s/sp.sqrt(d)
    - 8*delta
    + 16*c*s
)
checks["full_regularized_identity"] = sp.simplify(
    regularized - regularized_expected
) == 0

# Put p_LC=w/4 and u=p_LC+b.
ux, uy = sp.symbols("ux uy", real=True)
u = sp.Matrix([ux, uy])
w_sub = 4*(u-b)
completed_equation = sp.expand(
    regularized_expected.subs({wx: w_sub[0], wy: w_sub[1]}) / 8
)
checks["level_is_u2_minus_F"] = sp.simplify(
    completed_equation - (u.dot(u) - F)
) == 0

# Energy/Jacobi convention.
Hsym = sp.symbols("H")
CJ = -2*Hsym
checks["jacobi_CJ_equals_2c_on_H_minus_c"] = sp.simplify(CJ.subs(Hsym, -c) - 2*c) == 0

src_sha = sha256_file(source)
checks["source_sha256"] = src_sha == expected_source_sha

src = re.sub(r"\s+", "", source.read_text(encoding="utf-8"))
required_fragments = [
    "staticI MU=intervaldec(\"0.987849414390376\",\"0.987849414390376\");".replace(" ", ""),
    "P(I(1))-P(MU)+P(I(2)*MU)*s/sqrtp(d)-P(I(2)*CC)*s+P(MU*MU)*s+P(I(4))*powi(s,3)-P(I(4)*MU)*s*(x*x-y*y)",
    "I(1)-MU+I(2)*MU*s/sqrt(d)-I(2)*CC*s+MU*MU*s+I(4)*s*s*s-I(4)*MU*s*(x*x-y*y)",
]
checks["source_formula_fragments"] = all(fragment in src for fragment in required_fragments)

result = {
    "status": "PASS" if all(checks.values()) else "FAIL",
    "checks": checks,
    "source_sha256": src_sha,
    "derived_formula": (
        "F=1-M+2*M*s/sqrt(1-4*(x^2-y^2)+4*s^2)"
        "-2*c*s+M^2*s+4*s^3-4*M*s*(x^2-y^2)"
    ),
    "mass_relation": "standard_small_mu = 1-M",
    "energy_relation": "Sigma_c=H^{-1}(-c), C_J=2c",
}
print(json.dumps(result, indent=2, sort_keys=True))
sys.exit(0 if result["status"] == "PASS" else 1)
