# Earth–Moon PCR3BP GitHub repository

This package contains the English and Portuguese manuscripts, LaTeX and DOCX sources, figures, bibliography, reproducibility code, GitHub/Zenodo metadata templates, cover letters, and release checks.

## Identifiers to fill

- GitHub: `xxxxx`
- Zenodo: `xxxxx`
- DOI: `xxxxx`
- ORCID: `xxxxx`
- Affiliation: `xxxxx`
- Email: `xxxxx`
- Funding: `xxxxx`

## Main result

For the Earth–Moon mass ratio, the bounded lunar component is certified globally strictly convex after exact antipodal symplectic transformations for every regular subcritical energy `c > c_L1`, with `c_L1 in [1.5941705588746069,1.5941705588746333]`. The contact-topological consequence is a rational disk-like global surface of section bound by Birkhoff's retrograde orbit.

## Build

```bash
make verify
make manuscript
make package
```

The large certificate parents are not duplicated here. They are identified by immutable SHA-256 hashes and should be deposited in Zenodo `xxxxx`.
