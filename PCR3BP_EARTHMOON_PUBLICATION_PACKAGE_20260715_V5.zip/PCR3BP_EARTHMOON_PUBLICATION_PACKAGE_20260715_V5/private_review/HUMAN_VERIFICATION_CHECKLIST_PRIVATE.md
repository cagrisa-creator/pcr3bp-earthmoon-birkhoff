# Private pre-publication mathematical verification

**Submission gate:** all ten items must be checked and signed by an independent mathematical reviewer before submission or arXiv posting.

Reviewer: ____________________  Institution: ____________________  Date: __________

1. [ ] Hamiltonian and energy convention.
2. [ ] Levi–Civita canonical derivation.
3. [ ] Exactness and antipodal property of the shear.
4. [ ] Identification of `Br` with the tangential Hessian.
5. [ ] Regularity, compactness, connectedness, and orientation gates.
6. [ ] Exact interval interfaces and all parent hashes.
7. [ ] Strict convexity, radial star-shapedness, Liouville primitive, and transport to dynamical convexity.
8. [ ] Topology of the retrograde orbit in `RP3`, including the 2-unknot and rational self-linking computation.
9. [ ] Exact hypotheses of the Hryniewicz–Salomão theorem and applicability of its published correction.
10. [ ] Clean-environment reproduction of the manuscript, `make verify`, parent verification, and cross-compiler replay.

Reviewer conclusion: [ ] Approved for submission  [ ] Corrections required

Signature: ______________________________
