# Corrections audit — version 2

1. Fixed the critical symbolic source paths; `make verify` now targets `src/core/outer_dynamic.cpp`.
2. Added and cited Liu–Salomão, arXiv:2506.17867.
3. Added do Carmo–Lima (1969), the general hypersurface Hadamard theorem.
4. Added a full contact-transport lemma, including `Phi^*lambda_0=lambda_0-dG`, star-shapedness, time reparametrization, indices, and antipodal descent.
5. Expanded the L1 bridge and added a dedicated appendix.
6. Reconciled 2,963,381 versus 2,968,830 Kepler leaves.
7. The V2 ZIP has external SHA-256 and post-extraction verification sidecars.
8. Kept the intentional metadata placeholders.
9. Changed LaTeX to a clean rebuild and added log validation.
10. Strengthened the signed human-review gate, especially items 7–9.
11. Corrected the malformed English formula `u=\frac2.44+b` to `u=w/4+b`.
